from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, override
from zoneinfo import ZoneInfo

import pandas as pd

from systrade.data import Bar, BarData


class Feed(ABC):
    @abstractmethod
    def start(self) -> None:
        """Start streaming"""

    @abstractmethod
    def stop(self) -> None:
        """Stop streaming"""

    @abstractmethod
    def is_running(self) -> bool:
        """Whether feed is currently running"""

    @abstractmethod
    def subscribe(self, symbol: str) -> None:
        """Subscribe to a symbol"""

    @abstractmethod
    def next_data(self) -> BarData:
        """Block until returning the next available data for subscribed
        symbols"""


class FileFeed(Feed):
    def __init__(
        self, path: str | Path, start: Optional[str] = None, end: Optional[str] = None
    ) -> None:
        """File feed initializer

        Parameters
        ----------
        path
            Full path to data file
        start, optional
            When to start the replay, in YYYY-MM-DD format
        end, optional
            When to end the replay, in YYYY-MM-DD format
        """

        # Your implementation

    @property
    def df(self) -> pd.DataFrame:
        pass

        # Your implementation

    @override
    def start(self) -> None:
        pass

        # Your implementation

    @override
    def stop(self) -> None:
        pass

        # Your implementation

    @override
    def is_running(self) -> bool:
        pass

        # Your implementation

    @override
    def subscribe(self, symbol: str) -> None:
        pass

        # Your implementation

    @override
    def next_data(self) -> BarData:
        
        # Your implementation
